import express from "express";
import { ethers } from "ethers";

const app = express();
const provider = new ethers.JsonRpcProvider("https://polygon-rpc.com");

app.get("/balance/:addr", async (req, res) => {
  const bal = await provider.getBalance(req.params.addr);
  res.json({ balance: ethers.formatEther(bal) });
});

app.listen(3000, () => console.log("API running"));
