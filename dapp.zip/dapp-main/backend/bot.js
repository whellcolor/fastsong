import { ethers } from "ethers";
import { RPC, TARGET_WALLETS, MIN_BALANCE, TOPUP_AMOUNT } from "./config.js";

const PRIVATE_KEY = process.env.PRIVATE_KEY;

const provider = new ethers.JsonRpcProvider(RPC);
const wallet = new ethers.Wallet(PRIVATE_KEY, provider);

async function checkAndTopup() {
  for (let addr of TARGET_WALLETS) {
    const bal = await provider.getBalance(addr);

    if (bal < ethers.parseEther(MIN_BALANCE)) {
      console.log("Top-up:", addr);

      const tx = await wallet.sendTransaction({
        to: addr,
        value: ethers.parseEther(TOPUP_AMOUNT)
      });

      await tx.wait();
    }
  }
}

setInterval(checkAndTopup, 300000); // tiap 5 menit

