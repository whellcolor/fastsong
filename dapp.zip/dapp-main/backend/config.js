export const RPC = "https://polygon-rpc.com";

export const TARGET_WALLETS = [
  "0x5E8Bade6E0BCe65807dB6327cB1D9EEb7C6A6A5B",
  "0xUser1...",
  "0xUser2..."
];

export const MIN_BALANCE = "0.01";
export const TOPUP_AMOUNT = "0.05";
