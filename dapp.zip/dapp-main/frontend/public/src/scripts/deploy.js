const hre = require("hardhat");

async function main() {
  const MinerReward = await hre.ethers.getContractFactory("MinerReward");
  const contract = await MinerReward.deploy();

  await contract.waitForDeployment();

  console.log("Contract deployed to:", await contract.getAddress());
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

async function main() {
  const NFT = await hre.ethers.getContractFactory("BoostNFT");
  const nft = await NFT.deploy();
  await nft.waitForDeployment();

  const Miner = await hre.ethers.getContractFactory("MinerReward");
  const miner = await Miner.deploy(await nft.getAddress());
  await miner.waitForDeployment();

  console.log("NFT:", await nft.getAddress());
  console.log("Miner:", await miner.getAddress());
}

main();
