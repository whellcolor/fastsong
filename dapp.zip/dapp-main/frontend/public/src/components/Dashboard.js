import { useState } from "react";
import { ethers } from "ethers";
import { getContract } from "../utils/web3";

export default function Dashboard() {
  const [account, setAccount] = useState("");
  const [pending, setPending] = useState("0");

  async function connect() {
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();

    const address = await signer.getAddress();
    setAccount(address);

    const contract = getContract(signer);

    const reward = await contract.getPending(address);
    setPending(ethers.formatEther(reward));
  }

  async function mine() {
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const contract = getContract(signer);

    const tx = await contract.mine();
    await tx.wait();

    alert("Mining success +1 power");
  }

  async function claim() {
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const contract = getContract(signer);

    const tx = await contract.claimRewards();
    await tx.wait();

    alert("Reward claimed!");
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>⛏ Mining Dashboard</h2>

      <button onClick={connect}>Connect Wallet</button>
      <p>Wallet: {account}</p>

      <hr />

      <h3>Pending Reward: {pending}</h3>

      <button onClick={mine}>Mine (+1 Power)</button>
      <button onClick={claim}>Claim Reward</button>
    </div>
  );
}


