import { ethers } from "ethers";
import { getContract } from "../utils/web3";

export default function ClaimButton() {

  const claim = async () => {
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();

    const contract = getContract(signer);

    const tx = await contract.claimRewards();
    await tx.wait();

    alert("Reward claimed!");
  };

  return <button onClick={claim}>Claim Reward</button>;
}

