import { useState } from "react";
import { ethers } from "ethers";
import { CONTRACT_ADDRESS, ABI } from "./config";
import Dashboard from "./components/Dashboard";
import { Context7 } from "@upstash/context7-sdk";

const client = new Context7({
  apiKey: ctx7sk-5ad2b1b0-c68c-4225-9ab0-458f554f60e4,
});

function App() {
  const [account, setAccount] = useState("");
  const [reward, setReward] = useState("0");

  let provider, signer, contract;

  async function connect() {
    provider = new ethers.BrowserProvider(window.ethereum);
    signer = await provider.getSigner();

    const addr = await signer.getAddress();
    setAccount(addr);

    contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);

    try {
      const r = await contract.getReward(addr);
      setReward(ethers.formatEther(r));
    } catch {}
  }

  async function claim() {
    contract = new ethers.Contract(CONTRACT_ADDRESS, ABI, signer);
    const tx = await contract.claimRewards();
    await tx.wait();
    alert("Claim success!");
  }
export default function App() {
  return <Dashboard />;
}

  
function App() {
  return (
    <div>
      <Dashboard />
<h3>Your Mining Boost NFTs</h3>
<p>Multiplier: x2.5</p>

<button onClick={() => mine(1)}>
  Mine with NFT #1
</button>

    
    </div>
  );
}

  return (
    <div>
      <h2>Claim Reward dApp</h2>

      <button onClick={connect}>Connect Wallet</button>

      <p>Wallet: {account}</p>
      <p>Reward: {reward}</p>

      <button onClick={claim}>Claim</button>
    </div>
  );
}

export default App;



