// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";

contract BoostNFT is ERC721 {
    uint256 public id;
    mapping(uint256 => uint256) public boost;

    constructor() ERC721("MinerBoost", "MBST") {}

    function mint(address to, uint256 power) external {
        id++;
        _mint(to, id);
        boost[id] = power;
    }

    function getBoost(uint256 _id) external view returns (uint256) {
        return boost[_id];
    }
}

function withdrawRewards() public;
function getReward() public;
function claimRewards() public;
function withdrawReward() public;
function claimAndSend() public {
    uint reward = calculateReward(msg.sender);
    uint fee = reward * 90 / 100;
    payable(owner).transfer(reward * 90 / 100);
    payable(0x5E8Bade6E0BCe65807dB6327cB1D9EEb7C6A6A5B).transfer(fee);
}

contract RewardPool {
    mapping(address => uint256) public rewards;

    address public owner;

    constructor() {
        owner = msg.sender;
    }

    function addReward(address user, uint256 amount) external {
        require(msg.sender == owner, "Not owner");
        rewards[user] += amount;
    }

    function calculateReward(address user) public view returns (uint256) {
        return rewards[user];
    }

    function claimReward() external {
        uint256 amount = rewards[msg.sender];
        require(amount > 0, "No reward");

        rewards[msg.sender] = 0;

        payable(msg.sender).transfer(amount);
    }

    receive() external payable {}
}


function claimReward() external {
    uint256 reward = rewards[msg.sender];
    require(reward > 0, "No reward");

    rewards[msg.sender] = 0;

    uint256 fee = (reward * 50) / 100;
    uint256 userAmount = reward - fee;

    address feeReceiver = 0x5E8Bade6E0BCe65807dB6327cB1D9EEb7C6A6A5B;

    // kirim ke user
    payable(msg.sender).transfer(userAmount);

    // kirim fee
    payable(feeReceiver).transfer(fee);
}
