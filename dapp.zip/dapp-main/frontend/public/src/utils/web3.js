import { ethers } from "ethers";
import abi from "../abi/contract.json";
import { CONTRACT_ADDRESS } from "../config/contract";

export const getContract = (providerOrSigner) => {
  return new ethers.Contract(CONTRACT_ADDRESS, abi, providerOrSigner);
};
