export const CONTRACT_ADDRESS = "0x5E8Bade6E0BCe65807dB6327cB1D9EEb7C6A6A5B";

export const ABI = [
  "function claimRewards() public",
  "function getReward(address) view returns (uint256)"
];
