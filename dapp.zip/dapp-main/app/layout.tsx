import Script from "next/script";

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        {children}
        <Script
          src="https://context7.com/widget.js"
          data-library="/owner/repo"
          strategy="afterInteractive"
        />

        <script
  src="https://context7.com/widget.js"
  data-library="/vercel/next.js"
  data-color="#0070F3"
  data-position="bottom-left"
></script>
<script
  src="https://context7.com/widget.js"
  data-library="/vercel/next.js"
  data-placeholder="Ask me anything about Next.js..."
></script>
        
      </body>
    </html>
  );
}
