import { resolveLibraryId, queryDocs } from "@upstash/context7-tools-ai-sdk";
import { generateText, stepCountIs } from "ai";
import { openai } from "@ai-sdk/openai";

const { text } = await generateText({
  model: openai("gpt-5.2"),
  prompt: "Show me how to set up routing in Next.js App Router",
  tools: {
    resolveLibraryId: resolveLibraryId(),
    queryDocs: queryDocs(),
  },
  stopWhen: stepCountIs(5),
});

// The model will:
// 1. Call resolveLibraryId to get the library ID
// 2. Call queryDocs({ libraryId: "/vercel/next.js", query: "routing in App Router" })
// 3. Generate a response using the fetched documentation

import { queryDocs } from "@upstash/context7-tools-ai-sdk";
import { generateText, stepCountIs } from "ai";
import { openai } from "@ai-sdk/openai";

const { text } = await generateText({
  model: openai("gpt-5.2"),
  prompt: "Using /vercel/next.js, explain middleware",
  tools: {
    queryDocs: queryDocs(),
  },
  stopWhen: stepCountIs(3),
});

// The model recognizes the /org/project format and calls queryDocs directly

import { resolveLibraryId, queryDocs } from "@upstash/context7-tools-ai-sdk";
import { generateText, stepCountIs } from "ai";
import { anthropic } from "@ai-sdk/anthropic";

const { text } = await generateText({
  model: anthropic("claude-sonnet-4-20250514"),
  prompt: "Give me a comprehensive guide to Supabase authentication",
  tools: {
    resolveLibraryId: resolveLibraryId(),
    queryDocs: queryDocs(),
  },
  stopWhen: stepCountIs(8), // Allow more steps for multiple queries
});

// The model may call queryDocs multiple times with different queries
// to gather comprehensive documentation

  // Latest version
"/vercel/next.js";

// Specific version
"/vercel/next.js/v14.3.0-canary.87";


